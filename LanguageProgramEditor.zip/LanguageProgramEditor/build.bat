@echo off
setlocal
cd /d "%~dp0"
dotnet publish LanguageProgramEditor.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
if errorlevel 1 (
    echo.
    echo Build failed.
    exit /b %errorlevel%
)
echo.
echo Published executable: bin\Release\net8.0-windows\win-x64\publish\LanguageProgramEditor.exe
endlocal
