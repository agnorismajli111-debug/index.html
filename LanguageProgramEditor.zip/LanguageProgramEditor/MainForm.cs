using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace LanguageProgramEditor;

public sealed class MainForm : Form
{
    private static readonly Color CanvasColor = Color.FromArgb(244, 246, 243);
    private static readonly Color InkColor = Color.FromArgb(32, 40, 39);
    private static readonly Color MutedColor = Color.FromArgb(104, 116, 111);
    private static readonly Color AccentColor = Color.FromArgb(26, 117, 98);
    private static readonly LanguageOption[] Languages =
    [
        new("C", ".c"),
        new("C++", ".cpp"),
        new("Python", ".py"),
        new("HTML", ".html"),
        new("C#", ".cs")
    ];

    private readonly Panel page = new() { Dock = DockStyle.Fill };
    private readonly RichTextBox editor = new();
    private readonly Label statusLabel = new();
    private readonly Dictionary<string, string> drafts = new(StringComparer.Ordinal);
    private readonly Dictionary<string, string> savedPaths = new(StringComparer.Ordinal);
    private LanguageOption? selectedLanguage;
    private string? currentFilePath;
    private HtmlPreviewForm? htmlPreview;

    public MainForm()
    {
        Text = "Language Program Editor";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(760, 540);
        ClientSize = new Size(1040, 720);
        BackColor = CanvasColor;
        Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        Controls.Add(page);
        ShowLanguagePicker();
    }

    private void ShowLanguagePicker()
    {
        page.Controls.Clear();
        page.BackColor = CanvasColor;
        page.Padding = new Padding(54, 42, 54, 38);

        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 5,
            BackColor = CanvasColor
        };
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));

        content.Controls.Add(new Label
        {
            Text = "LANGUAGE PROGRAM EDITOR",
            Dock = DockStyle.Fill,
            ForeColor = AccentColor,
            Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 0);
        content.Controls.Add(new Label
        {
            Text = "Which language program do you want to start?",
            Dock = DockStyle.Fill,
            ForeColor = InkColor,
            Font = new Font("Segoe UI Semibold", 21F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 1);
        content.Controls.Add(new Label
        {
            Text = "Choose a language to open a new source file.",
            Dock = DockStyle.Fill,
            ForeColor = MutedColor,
            Font = new Font("Segoe UI", 11F),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 2);

        var options = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(0, 14, 0, 0),
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            BackColor = CanvasColor
        };
        var radioButtons = new List<RadioButton>();
        foreach (var language in Languages)
        {
            var optionButton = new RadioButton
            {
                Appearance = Appearance.Button,
                AutoSize = false,
                Size = new Size(270, 66),
                Margin = new Padding(0, 0, 12, 12),
                Padding = new Padding(16, 0, 10, 0),
                Text = $"{language.Name}    {language.Extension}",
                TextAlign = ContentAlignment.MiddleLeft,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = InkColor,
                Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold),
                UseVisualStyleBackColor = false,
                Tag = language,
                Checked = selectedLanguage == language
            };
            optionButton.FlatAppearance.BorderColor = Color.FromArgb(216, 223, 218);
            optionButton.FlatAppearance.BorderSize = 1;
            optionButton.CheckedChanged += (_, _) =>
            {
                if (!optionButton.Checked)
                    return;

                selectedLanguage = language;
                foreach (var sibling in radioButtons)
                {
                    sibling.BackColor = sibling.Checked ? Color.FromArgb(225, 240, 233) : Color.White;
                    sibling.FlatAppearance.BorderColor = sibling.Checked
                        ? AccentColor
                        : Color.FromArgb(216, 223, 218);
                }
            };
            radioButtons.Add(optionButton);
            options.Controls.Add(optionButton);
        }
        content.Controls.Add(options, 0, 3);

        var startButton = CreateButton("Start", AccentColor, Color.White, 150);
        startButton.Dock = DockStyle.Right;
        startButton.Enabled = selectedLanguage is not null;
        startButton.Click += (_, _) => ShowEditor();
        content.Controls.Add(startButton, 0, 4);
        page.Controls.Add(content);
    }

    private void ShowEditor()
    {
        if (selectedLanguage is null)
            return;

        currentFilePath = savedPaths.GetValueOrDefault(selectedLanguage.Name);
        page.Controls.Clear();
        page.Padding = new Padding(22, 18, 22, 14);
        page.BackColor = Color.White;

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            BackColor = Color.White
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));

        var toolbar = new Panel { Dock = DockStyle.Fill, BackColor = Color.White };
        toolbar.Controls.Add(new Label
        {
            Text = $"{selectedLanguage.Name}  /  {selectedLanguage.Extension}",
            Dock = DockStyle.Left,
            Width = 300,
            TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = InkColor,
            Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold)
        });

        var actions = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            Width = 280,
            FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false,
            BackColor = Color.White,
            Padding = new Padding(0, 7, 0, 0)
        };
        var backButton = CreateButton("Back", Color.FromArgb(232, 237, 233), InkColor, 88);
        var clearButton = CreateButton("Clear", Color.FromArgb(232, 237, 233), InkColor, 88);
        var saveButton = CreateButton("Save", AccentColor, Color.White, 88);
        backButton.Click += (_, _) => GoBack();
        clearButton.Click += (_, _) => ClearEditor();
        saveButton.Click += (_, _) => Save();
        actions.Controls.Add(backButton);
        actions.Controls.Add(clearButton);
        actions.Controls.Add(saveButton);
        toolbar.Controls.Add(actions);

        editor.Dock = DockStyle.Fill;
        editor.BorderStyle = BorderStyle.FixedSingle;
        editor.BackColor = Color.FromArgb(250, 251, 249);
        editor.ForeColor = InkColor;
        editor.Font = new Font("Consolas", 12F, FontStyle.Regular, GraphicsUnit.Point);
        editor.AcceptsTab = true;
        editor.DetectUrls = false;
        editor.WordWrap = false;
        editor.ScrollBars = RichTextBoxScrollBars.Both;
        editor.HideSelection = false;
        editor.Text = drafts.GetValueOrDefault(selectedLanguage.Name, string.Empty);
        editor.TextChanged -= EditorTextChanged;
        editor.TextChanged += EditorTextChanged;

        statusLabel.Dock = DockStyle.Fill;
        statusLabel.TextAlign = ContentAlignment.MiddleLeft;
        statusLabel.ForeColor = MutedColor;
        statusLabel.Text = currentFilePath is null ? "New file" : Path.GetFileName(currentFilePath);
        statusLabel.Font = new Font("Segoe UI", 9F);

        layout.Controls.Add(toolbar, 0, 0);
        layout.Controls.Add(editor, 0, 1);
        layout.Controls.Add(statusLabel, 0, 2);
        page.Controls.Add(layout);

        if (selectedLanguage.Name == "HTML")
        {
            htmlPreview = new HtmlPreviewForm();
            htmlPreview.FormClosed += PreviewClosed;
            htmlPreview.Show(this);
            htmlPreview.ShowHtml(editor.Text);
        }
        editor.Focus();
    }

    private void EditorTextChanged(object? sender, EventArgs e)
    {
        if (selectedLanguage is null)
            return;

        drafts[selectedLanguage.Name] = editor.Text;
        if (selectedLanguage.Name == "HTML")
            htmlPreview?.ShowHtml(editor.Text);
    }

    private void PreviewClosed(object? sender, FormClosedEventArgs e)
    {
        if (ReferenceEquals(htmlPreview, sender))
            htmlPreview = null;
    }

    private void GoBack()
    {
        if (selectedLanguage is not null)
            drafts[selectedLanguage.Name] = editor.Text;

        ClosePreview();
        ShowLanguagePicker();
    }

    private void ClearEditor()
    {
        editor.Clear();
        if (selectedLanguage is not null)
        {
            drafts.Remove(selectedLanguage.Name);
            savedPaths.Remove(selectedLanguage.Name);
        }
        currentFilePath = null;
        statusLabel.Text = "Editor cleared";
        editor.Focus();
    }

    private void Save()
    {
        if (selectedLanguage is null)
            return;

        if (string.IsNullOrWhiteSpace(currentFilePath))
        {
            using var dialog = new SaveFileDialog
            {
                Title = $"Save {selectedLanguage.Name} program",
                FileName = $"untitled{selectedLanguage.Extension}",
                DefaultExt = selectedLanguage.Extension.TrimStart('.'),
                AddExtension = true,
                OverwritePrompt = true,
                Filter = $"{selectedLanguage.Name} files (*{selectedLanguage.Extension})|*{selectedLanguage.Extension}|All files (*.*)|*.*",
                FilterIndex = 1
            };

            if (dialog.ShowDialog(this) != DialogResult.OK)
                return;

            currentFilePath = dialog.FileName;
        }

        SaveToPath(currentFilePath);
    }

    private void SaveToPath(string path)
    {
        if (selectedLanguage is null)
            return;

        var otherLanguage = SourceLanguageDetector.FindForeignLanguage(editor.Text, selectedLanguage.Name);
        if (otherLanguage is not null)
        {
            MessageBox.Show(
                this,
                $"Language Program Not From {selectedLanguage.Name}. The code looks like {otherLanguage}.",
                "Language Program Not From Selected Language",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            return;
        }

        if (!string.Equals(Path.GetExtension(path), selectedLanguage.Extension, StringComparison.OrdinalIgnoreCase))
            path = Path.ChangeExtension(path, selectedLanguage.Extension);

        try
        {
            File.WriteAllText(path, editor.Text, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            currentFilePath = path;
            savedPaths[selectedLanguage.Name] = path;
            drafts[selectedLanguage.Name] = editor.Text;
            statusLabel.Text = $"Saved {Path.GetFileName(path)}";
        }
        catch (Exception exception)
        {
            MessageBox.Show(this, $"The program could not be saved.\n\n{exception.Message}", "Save Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ClosePreview()
    {
        if (htmlPreview is null)
            return;

        htmlPreview.FormClosed -= PreviewClosed;
        htmlPreview.Close();
        htmlPreview = null;
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        ClosePreview();
        base.OnFormClosed(e);
    }

    private static Button CreateButton(string text, Color background, Color foreground, int width)
    {
        var button = new Button
        {
            Text = text,
            Width = width,
            Height = 40,
            Margin = new Padding(0, 0, 8, 0),
            BackColor = background,
            ForeColor = foreground,
            Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold),
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            UseVisualStyleBackColor = false
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
