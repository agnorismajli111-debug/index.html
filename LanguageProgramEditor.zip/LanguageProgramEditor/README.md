# Language Program Editor

A small Windows desktop editor built with C# and .NET 8 WinForms. Choose C, C++, Python, HTML, or C#, then write and save a source file using that language's extension. The app is configured to publish as a self-contained, single-file `win-x64` executable.

## Build on Windows

Install the .NET 8 SDK, then double-click `build.bat` or run this from the project directory:

```powershell
dotnet publish LanguageProgramEditor.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
```

The executable will be at `bin\Release\net8.0-windows\win-x64\publish\LanguageProgramEditor.exe`.

## Use

Select a language and press **Start**. **Save** asks for a destination on the first save and overwrites the same file on later saves. **Clear** empties the editor and starts a new file. **Back** returns to the language chooser while keeping the current draft in memory. Saved source files use the selected language's extension: `.c`, `.cpp`, `.py`, `.html`, or `.cs`.

When HTML is selected, the editor opens a second **HTML Showcase** window and refreshes it as you type. The preview uses the Windows embedded browser engine.

Before saving, the editor checks for a few recognizable syntax signatures belonging to the other listed languages. This is a lightweight safeguard, not a full parser/compiler; the app does not run programs or require language runtimes.
