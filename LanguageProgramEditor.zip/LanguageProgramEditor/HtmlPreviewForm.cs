using System.Drawing;
using System.Windows.Forms;

namespace LanguageProgramEditor;

internal sealed class HtmlPreviewForm : Form
{
    private readonly WebBrowser browser = new();
    private readonly System.Windows.Forms.Timer refreshTimer = new() { Interval = 300 };
    private string pendingHtml = string.Empty;

    public HtmlPreviewForm()
    {
        Text = "HTML Showcase";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(420, 360);
        ClientSize = new Size(680, 620);
        BackColor = Color.White;

        browser.Dock = DockStyle.Fill;
        browser.AllowWebBrowserDrop = false;
        browser.IsWebBrowserContextMenuEnabled = true;
        browser.ScriptErrorsSuppressed = true;
        browser.WebBrowserShortcutsEnabled = true;
        Controls.Add(browser);

        refreshTimer.Tick += (_, _) =>
        {
            refreshTimer.Stop();
            browser.DocumentText = PrepareDocument(pendingHtml);
        };
        FormClosed += (_, _) => refreshTimer.Dispose();
    }

    public void ShowHtml(string html)
    {
        pendingHtml = html;
        refreshTimer.Stop();
        refreshTimer.Start();
    }

    private static string PrepareDocument(string html)
    {
        if (html.Contains("<!doctype", StringComparison.OrdinalIgnoreCase))
            return html;

        if (html.Contains("<html", StringComparison.OrdinalIgnoreCase))
            return "<!doctype html>\n" + html;

        return "<!doctype html><html><head><meta charset=\"utf-8\"></head><body>" + html + "</body></html>";
    }
}
