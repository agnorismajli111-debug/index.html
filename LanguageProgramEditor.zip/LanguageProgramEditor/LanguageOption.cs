namespace LanguageProgramEditor;

internal sealed record LanguageOption(string Name, string Extension);
