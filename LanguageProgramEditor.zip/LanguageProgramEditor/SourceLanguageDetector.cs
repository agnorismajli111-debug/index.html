using System.Text.RegularExpressions;

namespace LanguageProgramEditor;

internal static class SourceLanguageDetector
{
    private static readonly (string Name, Regex Pattern)[] Signatures =
    [
        ("HTML", new Regex(@"(?is)<!doctype\s+html|<(?:html|head|body|div|p|script|style|section|main|button|form|title|h[1-6])\b[^>]*>", RegexOptions.Compiled)),
        ("C++", new Regex(@"(?m)#\s*include\s*<iostream>|\bstd\s*::|\b(?:cout|cin|cerr)\s*(?:<<|>>)|\btemplate\s*<", RegexOptions.Compiled)),
        ("Python", new Regex(@"(?m)^\s*(?:def\s+\w+\s*\([^)]*\)\s*:|class\s+\w+(?:\([^)]*\))?\s*:|(?:if|elif|else|for|while|try|except|with)\b.*:\s*(?:#.*)?$)|\bprint\s*\(", RegexOptions.Compiled)),
        ("C#", new Regex(@"(?m)\busing\s+(?:System|Microsoft)(?:\.[\w.]+)?\s*;|\bConsole\s*\.\s*(?:Write|WriteLine|ReadLine)\s*\(|\bnamespace\s+[\w.]+\s*\{", RegexOptions.Compiled)),
        ("C", new Regex(@"(?m)#\s*include\s*<(?:stdio|stdlib|string|stdbool)\.h>|\b(?:printf|scanf|puts|malloc)\s*\(|\bint\s+main\s*\(\s*(?:void\s*)?\)", RegexOptions.Compiled))
    ];

    public static string? FindForeignLanguage(string source, string selectedLanguage)
    {
        var matches = Signatures
            .Where(signature => signature.Pattern.IsMatch(source))
            .Select(signature => signature.Name)
            .ToArray();

        if (matches.Contains(selectedLanguage, StringComparer.Ordinal))
            return null;

        return matches.FirstOrDefault(name => !string.Equals(name, selectedLanguage, StringComparison.Ordinal));
    }
}
